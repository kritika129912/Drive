function resetform() {
    document.getElementById("myform").reset();
    }
              